package ch.walica.a55_temp170326_3tp1_numberpicker;

import android.os.Bundle;
import android.widget.NumberPicker;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {

    private NumberPicker numberPicker1, numberPicker2;
    private TextView tvResult;
    private int selectedValue = 10;
    private String[] names = {"Jan", "Konrad", "Gustaw", "Adam"};
    private int selectedIndex = 2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        numberPicker1 = findViewById(R.id.numberPicker1);
        numberPicker2 = findViewById(R.id.numberPicker2);
        tvResult = findViewById(R.id.tvResult);

        if(savedInstanceState != null) {
            selectedValue = savedInstanceState.getInt("selected_number");
            selectedIndex = savedInstanceState.getInt("array_index_key");
        }


        numberPicker1.setMaxValue(20);
        numberPicker1.setMinValue(5);
        numberPicker1.setValue(selectedValue);

        numberPicker2.setMaxValue(names.length - 1);
        numberPicker2.setValue(selectedIndex);
        numberPicker2.setDisplayedValues(names);

        //tvResult.setText(String.valueOf(selectedValue));
        tvResult.setText(String.valueOf(names[selectedIndex]));

        numberPicker1.setOnValueChangedListener(new NumberPicker.OnValueChangeListener() {
            @Override
            public void onValueChange(NumberPicker numberPicker, int oldVal, int newVal) {
                selectedValue = newVal;
                tvResult.setText(String.valueOf(selectedValue));
            }
        });

        numberPicker2.setOnValueChangedListener((numberPicker, oldVal, newVal) -> {
            selectedIndex = newVal;
            tvResult.setText(String.valueOf(names[selectedIndex]));
        });
    }

    @Override
    protected void onSaveInstanceState(@NonNull Bundle outState) {
        super.onSaveInstanceState(outState);
        outState.putInt("array_index_key", selectedIndex);
        outState.putInt("selected_number", selectedValue);
    }
}
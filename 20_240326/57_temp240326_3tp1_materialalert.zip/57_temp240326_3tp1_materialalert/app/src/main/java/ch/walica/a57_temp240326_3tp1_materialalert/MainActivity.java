package ch.walica.a57_temp240326_3tp1_materialalert;

import android.content.DialogInterface;
import android.os.Bundle;
import android.widget.Button;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.google.android.material.dialog.MaterialAlertDialogBuilder;

public class MainActivity extends AppCompatActivity {

    private Button btnShowAlert;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        btnShowAlert = findViewById(R.id.btnShowAlert);

        AlertDialog alert = new MaterialAlertDialogBuilder(MainActivity.this)
                .setTitle(R.string.alert_title)
                .setMessage(getString(R.string.alert_msg))
                .setPositiveButton(R.string.btn_positive, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        finish();
                    }
                })
                .setNegativeButton(R.string.btn_negative, null)
                .setNeutralButton(R.string.btn_neutral, (dialogInterface, i) -> {
                    Toast.makeText(this, R.string.toast_msg, Toast.LENGTH_SHORT).show();
                })
                .setCancelable(false)
                .create();


        btnShowAlert.setOnClickListener(view -> {
//            new MaterialAlertDialogBuilder(MainActivity.this)
//                    .setTitle("Info")
//                    .setMessage("Do you want to close the application?")
//                    .setPositiveButton("Yes", new DialogInterface.OnClickListener() {
//                        @Override
//                        public void onClick(DialogInterface dialogInterface, int i) {
//                            finish();
//                        }
//                    })
//                    .setNegativeButton("No", null)
//                    .setNeutralButton("I don't know", (dialogInterface, i) -> {
//                        Toast.makeText(this, "You have to make a decision", Toast.LENGTH_SHORT).show();
//                    })
//                    .setCancelable(false)
//                    .show();
            alert.show();

        });
    }
}
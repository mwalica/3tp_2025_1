package ch.walica.a42_temp30226_3tp1_kostka;

import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.util.Random;

public class MainActivity extends AppCompatActivity {

    private TextView tvResult;
    private ImageView ivPhoto;
    private int count = 0;
    private Random random = new Random();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        tvResult = findViewById(R.id.tvResult);
        ivPhoto = findViewById(R.id.ivPhoto);

        tvResult.setText(String.valueOf(count));

        ivPhoto.setOnClickListener(view -> {
            int randomNumber = random.nextInt(6) + 1;
            count += randomNumber;
            tvResult.setText(String.valueOf(count));
            if(count >= 100) {
                Toast.makeText(this, "Poziom 100 osiągnięty ", Toast.LENGTH_SHORT).show();
                count = 0;
            }
            switch(randomNumber) {
                case 1:
                    ivPhoto.setImageResource(R.drawable.one);
                    break;
                case 2:
                    ivPhoto.setImageResource(R.drawable.two);
                    break;
                case 3:
                    ivPhoto.setImageResource(R.drawable.three);
                    break;
                case 4:
                    ivPhoto.setImageResource(R.drawable.four);
                    break;
                case 5:
                    ivPhoto.setImageResource(R.drawable.five);
                    break;
                case 6:
                    ivPhoto.setImageResource(R.drawable.six);
                    break;
            }
        });
    }
}
package ch.walica.a7_temp41125_3tp1_textview;

import android.graphics.Color;
import android.os.Bundle;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.util.Random;

public class MainActivity extends AppCompatActivity{

    private TextView tvText1;
    private TextView tvText2;


    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //pobieramu referencje do view z .xml-a
        tvText1 = findViewById(R.id.tvText1);
        tvText2 = findViewById(R.id.tvText2);

        tvText1.setText("To będzie nowy tekst w tekst 1");
        tvText2.setText(getResources().getString(R.string.text_3));

        tvText1.setBackgroundColor(getColor(R.color.white));
        tvText1.setBackgroundColor(Color.rgb(ranColor(), ranColor(), ranColor()));

        tvText2.setTextColor(Color.GREEN);
        tvText2.setBackgroundColor(Color.rgb(245, 61, 22));

    }

    private int ranColor() {
        return new Random().nextInt(256);
    }
}
package ch.walica.a28_temp130126_3tp1_grafika;

import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {
    private ImageView ivPhoto, icPhone;
    private boolean isLandscape2 = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        ivPhoto = findViewById(R.id.ivPhoto);
        icPhone = findViewById(R.id.icPhone);

        icPhone.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(isLandscape2) {
                    ivPhoto.setImageResource(R.drawable.landscape_1);
                    isLandscape2 = false;
                } else {
                    ivPhoto.setImageResource(R.drawable.landscape_2);
                    isLandscape2 = true;
                }

            }
        });

    }
}
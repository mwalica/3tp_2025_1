package ch.walica.a73_temp210426_3tp1_checkbox;

import android.graphics.Color;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {

    private EditText etEnteredText;
    private TextView tvResult;
    private CheckBox cbUpper, cbRed;

    private String enteredText = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        etEnteredText = findViewById(R.id.etEnteredText);
        tvResult = findViewById(R.id.tvResult);
        cbUpper = findViewById(R.id.cbUpper);
        cbRed = findViewById(R.id.cbRed);

        etEnteredText.addTextChangedListener(new TextWatcher() {
            @Override
            public void afterTextChanged(Editable editable) {

            }

            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                enteredText = charSequence.toString();
               upperText(cbUpper.isChecked());
               colorText(cbRed.isChecked());
            }
        });

        cbUpper.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(@NonNull CompoundButton compoundButton, boolean b) {
               upperText(b);
            }
        });

        cbRed.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(@NonNull CompoundButton compoundButton, boolean b) {
               colorText(cbRed.isChecked());
            }
        });
    }

    private void upperText(boolean state) {
        if(state) {
            enteredText = enteredText.toUpperCase();
        } else {
            enteredText = enteredText.toLowerCase();
        }
        tvResult.setText(enteredText);
    }

    private void colorText(boolean isRed) {
        if(isRed) {
            tvResult.setTextColor(Color.RED);
        } else {
            tvResult.setTextColor(Color.BLACK);
        }
    }
}
package ch.walica.a50_temp20326_3tp1_constrain_textwatcher_logd;

import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {

    private EditText etEnteredText;
    private TextView tvResult;
    private Button btnShow;

    private String enteredText = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        etEnteredText = findViewById(R.id.etEnteredText);
        tvResult = findViewById(R.id.tvResult);
        btnShow = findViewById(R.id.btnShow);

        tvResult.setText(enteredText);

        etEnteredText.addTextChangedListener(new TextWatcher() {
            @Override
            public void afterTextChanged(Editable editable) {

            }

            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                enteredText = charSequence.toString();
                tvResult.setText(enteredText);
                btnShow.setEnabled(!enteredText.isEmpty());
            }
        });

        btnShow.setOnClickListener(view -> {
            Log.d("my_log", "enteredtext = " + enteredText);
        });
    }
}
package ch.walica.a53_temp100326_3tp1_saveinstanceorientacja;

import android.os.Bundle;
import android.util.Log;
import android.widget.Button;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {

    private Button btnAdd, btnSub;
    private TextView tvCounter;
    private int counter = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        btnAdd = findViewById(R.id.btnAdd);
        btnSub = findViewById(R.id.btnSub);
        tvCounter = findViewById(R.id.tvCounter);

        if(savedInstanceState != null) {
            counter = savedInstanceState.getInt("counter_key", 0);
        }

        tvCounter.setText(String.valueOf(counter));

        btnAdd.setOnClickListener(view -> {
            counter++;
            tvCounter.setText(String.valueOf(counter));
        });

        btnSub.setOnClickListener(view -> {
            counter--;
            tvCounter.setText(String.valueOf(counter));
        });
    }

    @Override
    protected void onSaveInstanceState(@NonNull Bundle outState) {
        super.onSaveInstanceState(outState);
        outState.putInt("counter_key", counter);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        Log.d("my_log", "onDestroy działa");
    }
}
package ch.walica.a67_temp140426_3tp2_alert_view;

import android.content.DialogInterface;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.google.android.material.dialog.MaterialAlertDialogBuilder;

public class MainActivity extends AppCompatActivity {

    private Button btnShowAlert;
    private TextView tvResult;
    private EditText etEnteredText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        btnShowAlert = findViewById(R.id.btnShowAlert);
        tvResult = findViewById(R.id.tvResult);


        btnShowAlert.setOnClickListener(view -> {
            View alertView = getLayoutInflater().inflate(R.layout.alert_view, null);
            etEnteredText = alertView.findViewById(R.id.etEnteredText);

            new MaterialAlertDialogBuilder(MainActivity.this)
                    .setTitle("Wpisz tekst")
                    .setView(alertView)
                    .setPositiveButton("OK", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialogInterface, int i) {
                            String enteredText = etEnteredText.getText().toString().trim();
                            if(!enteredText.isEmpty()) {
                                tvResult.setText(enteredText);
                            } else {
                                Toast.makeText(MainActivity.this, "Formularz nie był wypełniony", Toast.LENGTH_SHORT).show();
                            }
                        }
                    })
                    .setNeutralButton("Anuluj", null)
                    .show();
        });
    }
}